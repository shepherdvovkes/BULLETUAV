#### OpenCV with Gstreamer on Windows

Links:
- https://galaktyk.medium.com/how-to-build-opencv-with-gstreamer-b11668fa09c
- https://stackoverflow.com/questions/78401254/unresolved-external-symbol-error-when-building-opencv-on-windows-with-gstreamer
